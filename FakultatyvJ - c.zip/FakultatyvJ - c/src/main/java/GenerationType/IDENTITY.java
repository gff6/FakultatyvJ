package GenerationType;

public class IDENTITY {
}
