document.addEventListener('DOMContentLoaded', () => {
    const courseForm = document.getElementById('courseForm');
    const courseList = document.getElementById('courseList');

    const fetchCourses = async () => {
        const response = await fetch('/courses');
        const courses = await response.json();
        courseList.innerHTML = '';
        courses.forEach(course => {
            const li = document.createElement('li');
            li.textContent = course.name;
            courseList.appendChild(li);
        });
    };

    courseForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const courseName = document.getElementById('courseName').value;
        await fetch('/courses', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name: courseName })
        });
        fetchCourses();
    });

    fetchCourses();
});
