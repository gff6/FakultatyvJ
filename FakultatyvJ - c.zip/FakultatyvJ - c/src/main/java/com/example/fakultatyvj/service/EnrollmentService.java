package com.example.fakultatyvj.service;

import com.example.fakultatyvj.dao.EnrollmentDAO;
import com.example.fakultatyvj.model.Enrollment;

import java.util.List;

public class EnrollmentService {
    private final EnrollmentDAO enrollmentDAO = new EnrollmentDAO();

    public List<Enrollment> getAllEnrollments() {
        return enrollmentDAO.getAllEnrollments();
    }

    // Additional service methods
}
