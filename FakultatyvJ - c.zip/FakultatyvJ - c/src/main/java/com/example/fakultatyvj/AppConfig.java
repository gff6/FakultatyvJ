package com.example.fakultatyvj;

import com.example.fakultatyvj.repository.StudentRepository;
import com.example.fakultatyvj.service.StudentService;
import com.example.fakultatyvj.service.StudentServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public StudentService studentService(StudentRepository studentRepository) {
        return new StudentServiceImpl(studentRepository);
    }
}

