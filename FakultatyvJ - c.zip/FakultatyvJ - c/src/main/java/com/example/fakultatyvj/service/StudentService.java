package com.example.fakultatyvj.service;

import org.springframework.stereotype.Service;
import com.example.fakultatyvj.model.Student;

@Service
public class StudentService {

    public Object getAllStudents() {
        return null;
    }

    public Student getStudentById(Long id) {
        return null;
    }
}


