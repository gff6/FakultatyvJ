package com.example.fakultatyvj.service;

import com.example.fakultatyvj.dao.CourseDAO;

import java.util.Collections;
import java.util.List;

public class CourseService {
    private final CourseDAO courseDAO = new CourseDAO();

    public List<Object> getAllCourses() {
        return Collections.singletonList(Collections.unmodifiableList(courseDAO.getAllCourses()));
    }

    // Additional service methods
}
