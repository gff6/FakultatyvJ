package com.example.fakultatyvj.dao;

import com.example.fakultatyvj.model.Enrollment;
import com.example.fakultatyvj.model.Student;
import com.example.fakultatyvj.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class StudentDAO {

    public List<Object> getAllStudents() {
        List<Student> students = new ArrayList<>();
        Connection connection = DatabaseUtil.getConnection();
        String sql = "SELECT * FROM fakultatyv.students";

        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Student student = new Student();
                student.setId((int) rs.getInt("id"));
                student.setName(rs.getString("name"));
                // Додаткові поля студента
                students.add(student);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return Collections.singletonList(students);
    }

    // Додаткові методи CRUD для студентів
}

