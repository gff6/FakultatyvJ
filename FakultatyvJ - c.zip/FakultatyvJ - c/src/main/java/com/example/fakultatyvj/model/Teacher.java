package com.example.fakultatyvj.model;

public class Teacher {
    private int id;
    private String name;
    private String email;

    public void setId(int id) {
    }

    public void setName(String name) {
    }

    public void setEmail(String email) {
    }

    // Getters and setters
}
