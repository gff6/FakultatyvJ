package com.example.fakultatyvj.dao;

import com.example.fakultatyvj.model.Teacher;
import com.example.fakultatyvj.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TeacherDAO {

    public List<Teacher> getAllTeachers() {
        List<Teacher> teachers = new ArrayList<>();
        Connection connection = DatabaseUtil.getConnection();
        String sql = "SELECT * FROM fakultatyv.teachers";

        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Teacher teacher = new Teacher();
                teacher.setId(rs.getInt("id"));
                teacher.setName(rs.getString("name"));
                teacher.setEmail(rs.getString("email"));
                teachers.add(teacher);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Реверсувати список
        Collections.reverse(teachers);

        return teachers;
    }

    // Додаткові методи CRUD
}
