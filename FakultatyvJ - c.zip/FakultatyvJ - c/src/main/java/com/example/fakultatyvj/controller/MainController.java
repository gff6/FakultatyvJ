package com.example.fakultatyvj.controller;

import com.example.fakultatyvj.model.Student;
import com.example.fakultatyvj.service.StudentService;
import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    private final StudentService studentService;

    @Autowired
    public MainController(StudentService studentService) {
        this.studentService = studentService;
    }

    @GetMapping("/")
    public String home() {
        return "index";
    }



    @GetMapping("/students")
    public String getAllStudents(Model model) {
        List students = (List) studentService.getAllStudents();
        model.addAttribute("students", students);
        return "students"; // Повертає назву HTML файлу для сторінки зі списком студентів
    }



}






