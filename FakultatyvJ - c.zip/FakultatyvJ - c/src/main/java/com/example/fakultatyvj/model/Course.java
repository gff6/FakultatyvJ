package com.example.fakultatyvj.model;

public class Course {
    private int id;
    private String name;
    private int teacherId;

    public void setId(int id) {
    }

    public void setName(String name) {
    }

    public void setTeacherId(int teacherId) {
    }

    public String getName() {
        return null;
    }

    // Getters and setters
}
