package com.example.fakultatyvj.model;

public class Enrollment {
    private int studentId;
    private int courseId;
    private int grade;

    public void setStudentId(int studentId) {
    }

    public void setCourseId(int courseId) {
    }

    public void setGrade(int grade) {
    }

    // Getters and setters
}
