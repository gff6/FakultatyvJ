package com.example.fakultatyvj.controller;

import com.example.fakultatyvj.model.Student;
import com.example.fakultatyvj.service.StudentService;
import com.example.fakultatyvj.controller.MainController;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;

@Configuration
@SpringBootApplication
@EnableCaching
public class Main {

    public static void main(String[] args) {
        SpringApplication.run(Main.class, args);
    }

}