package com.example.fakultatyvj.service;

import com.example.fakultatyvj.dao.TeacherDAO;

import java.util.Collections;
import java.util.List;

public class TeacherService {
    private final TeacherDAO teacherDAO = new TeacherDAO();

    public List<Object> getAllTeachers() {
        return Collections.singletonList(teacherDAO.getAllTeachers());
    }

    // Additional service methods
}
